from tkinter import *

#Large Window
window=Tk()
window.title("Halloween Outfitters Order Form")
window.geometry('800x600')
window.configure(bg='orange')

#Variables for window entrys
name=StringVar()
costume=StringVar()
units=IntVar()
price=DoubleVar()

#Calculates total price with tax
def HalloweenOrder():
    netprice=units.get()*price.get()
    totalprice=netprice*1.07
    if units.get()>=2:
        message=f"{name.get()} your price for {units.get()} {costume.get()} costumes is ${totalprice:,.2f}"
        resultlabel.config(text=message)
    else:
        message=f"{name.get()} your price for {units.get()} {costume.get()} costume is ${totalprice:,.2f}"
        resultlabel.config(text=message)

#Pumpkin Photo
photo= PhotoImage(file='Pumpkin.png')

#Resize the photo
new_width=275
new_height=200
photo=photo.subsample(int(photo.width()/new_width),int(photo.height()/new_height))

#Display Photo
labelp= Label(window, image=photo)
labelp.place(relx=.3,rely=.7,anchor='center')

#Creates window to input name
label1=Label(window,text='Enter your name:',fg='black', font=('Arial',14))
label1.grid(row=0,column=0,padx=5,pady=10)

textbox1=Entry(window,textvariable=name, fg='black',font=('Arial',14))
textbox1.grid(row=0,column=1)

#Creates window to input costumes
label2=Label(window,text='Enter your desired costume:',fg='black', font=('Arial',14))
label2.grid(row=1,column=0,padx=5,pady=10)

textbox2=Entry(window,textvariable=costume, fg='black',font=('Arial',14))
textbox2.grid(row=1,column=1)

#Creates window to input units
label3=Label(window,text='How many would you like:',fg='black', font=('Arial',14))
label3.grid(row=2,column=0,padx=5,pady=10)

textbox3=Entry(window,textvariable=units, fg='black',font=('Arial',14))
textbox3.grid(row=2,column=1)

#Creates window to input price
label4=Label(window,text='Enter the price:',fg='black', font=('Arial',14))
label4.grid(row=3,column=0,padx=5,pady=10)

textbox4=Entry(window,textvariable=price, fg='black',font=('Arial',14))
textbox4.grid(row=3,column=1)

#Button runs the HalloweenOrder function 
button1=Button(window,command=HalloweenOrder,text='Enter',fg='black',font=('Arial',14))
button1.grid(row=4,column=1)

#Window that displays the output
resultlabel=Label(window,fg='black',font=('Arial',14))
resultlabel.configure(bg='orange')
resultlabel.place(relx=.3,rely=.4,anchor='center')

window.mainloop()


